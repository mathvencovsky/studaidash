# Missing Dashboard Functionalities

Comparison between studaidash.lovable.app "Início" page and localhost:5173 home page.

## 1. Personalized Greeting
- Shows user's name ("Olá, João") instead of user ID
- Subtitle: "Visão geral do seu progresso"

## 2. Next Recommended Session Card
- Module name (e.g., "Probability Concepts")
- Duration (45 min)
- "Continuar estudo" button
- "Retomar do último ponto" hint

## 3. Today's Plan ("Plano de hoje")
- Progress indicator (0/4 tasks)
- Task list with types and durations:
  - Leitura guiada (Guided reading) - 25 min
  - Prática (Practice) - 20 min
  - Micro-resumo (Summary) - 10 min
  - Mini-quiz - 20 min
- "Iniciar plano" button

## 4. Track Status ("Status da trilha")
- Track name, start/end dates
- Hours studied vs remaining
- Days remaining
- Required time per day
- Progress percentage
- Status indicator ("No ritmo")

## 5. Active Track Card ("Trilha ativa")
- Progress %, module count, hours
- Current module to continue
- "Trocar" (switch) and "Iniciar sessão" buttons

## 6. Gamification ("Progresso acumulado")
- Active days count
- Level and XP
- Progress bar to next level
- Recent achievements with icons

## 7. Modules List ("Módulos")
- Overall completion %
- Individual module progress bars
- Clickable module buttons

## 8. Assessments ("Avaliações")
- Quiz list with question counts
- Last attempt scores
- Simulados (mock exams) with duration
- Action buttons (Continuar, Iniciar quiz, Iniciar simulado)

## 9. AI Recommendation ("Próxima Melhor Ação")
- Personalized study suggestion
- "Revisar módulo" action button

## 10. Header Features
- Search bar
- "Nova sessão" button

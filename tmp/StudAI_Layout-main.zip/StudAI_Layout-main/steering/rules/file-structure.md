# File Structure Guidelines

When managing files, always follow these guidelines

## Always use Kebab Case when creating folder

For any folders, always use kebab case

Wrong way:

- MyFolder/
- myFolder/

Correct way:

- my-folder/

## Always use Kebab Case when creating Javascript or Typescript files

Always use Kebab Case when creating a new file with the following extesions ".js", ".jsx", ".ts", ".tsx"

Wrong way:

- MyButton.tsx
- myButton.tsx

Correct way:

- my-button.tsx

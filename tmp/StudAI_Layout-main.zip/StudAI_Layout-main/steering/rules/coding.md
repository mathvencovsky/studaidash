# Coding guidelines

For code you write, follow these guidelines

## Do not shorten variable names

When declaring a varible, always put the entire name. Do not shorten variable names.

Wrong example:

```ts
listC = ["..."];
```

Correct example:

```ts
listContent = ["..."];
```

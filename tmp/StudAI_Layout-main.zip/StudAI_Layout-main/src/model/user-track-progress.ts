import { type Schema } from "../../amplify/data/resource";

export type UserTrackProgress = Schema["UserTrackProgress"]["type"];
export type UserTrackProgressIdentifier =
  Schema["UserTrackProgress"]["identifier"];
export type UserTrackProgressCreateInput =
  Schema["UserTrackProgress"]["createType"];
export type UserTrackProgressUpdateInput =
  Schema["UserTrackProgress"]["updateType"];

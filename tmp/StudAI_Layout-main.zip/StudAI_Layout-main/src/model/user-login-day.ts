import { type Schema } from "../../amplify/data/resource";

export type UserLoginDay = Schema["UserLoginDay"]["type"];
export type UserLoginDayCreateInput = Schema["UserLoginDay"]["createType"];

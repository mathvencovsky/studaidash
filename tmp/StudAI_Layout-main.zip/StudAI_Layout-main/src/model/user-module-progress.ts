import { type Schema } from "../../amplify/data/resource";

export type UserModuleProgress = Schema["UserModuleProgress"]["type"];
export type UserModuleProgressIdentifier =
  Schema["UserModuleProgress"]["identifier"];
export type UserModuleProgressCreateInput =
  Schema["UserModuleProgress"]["createType"];
export type UserModuleProgressUpdateInput =
  Schema["UserModuleProgress"]["updateType"];
export type UserModuleProgressDeleteInput =
  Schema["UserModuleProgress"]["deleteType"];

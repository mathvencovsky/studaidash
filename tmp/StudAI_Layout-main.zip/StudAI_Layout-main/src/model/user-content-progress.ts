import { type Schema } from "../../amplify/data/resource";

export type UserContentProgress = Schema["UserContentProgress"]["type"];
export type UserContentProgressIdentifier =
  Schema["UserContentProgress"]["identifier"];
export type UserContentProgressCreateInput =
  Schema["UserContentProgress"]["createType"];
export type UserContentProgressUpdateInput =
  Schema["UserContentProgress"]["updateType"];
export type UserContentProgressDeleteInput =
  Schema["UserContentProgress"]["deleteType"];

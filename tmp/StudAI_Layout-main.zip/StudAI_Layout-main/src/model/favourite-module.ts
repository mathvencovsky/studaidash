import { type Schema } from "../../amplify/data/resource";

export type FavouriteModule = Schema["FavouriteModule"]["type"];
export type FavouriteModuleIdentifier = Schema["FavouriteModule"]["identifier"];
export type FavouriteModuleCreateInput =
  Schema["FavouriteModule"]["createType"];
export type FavouriteModuleDeleteInput =
  Schema["FavouriteModule"]["deleteType"];

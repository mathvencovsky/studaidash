export interface UserStats {
  totalHoursStudied: number;
  totalModulesCompleted: number;
  totalDaysLoggedIn: number;
}

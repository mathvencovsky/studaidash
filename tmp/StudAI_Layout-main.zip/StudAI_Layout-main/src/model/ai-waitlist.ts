import { type Schema } from "../../amplify/data/resource";

export type AiWaitlist = Schema["AiWaitlist"]["type"];
export type AiWaitlistIdentifier = Schema["AiWaitlist"]["identifier"];
export type AiWaitlistCreateInput = Schema["AiWaitlist"]["createType"];

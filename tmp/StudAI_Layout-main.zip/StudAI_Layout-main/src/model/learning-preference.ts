import { type Schema } from "../../amplify/data/resource";

export type LearningPreference = Schema["LearningPreference"]["type"];
export type LearningPreferenceIdentifier =
  Schema["LearningPreference"]["identifier"];
export type LearningPreferenceCreateInput =
  Schema["LearningPreference"]["createType"];
export type LearningPreferenceUpdateInput =
  Schema["LearningPreference"]["updateType"];
export type LearningPreferenceDeleteInput =
  Schema["LearningPreference"]["deleteType"];

import { type Schema } from "../../amplify/data/resource";

export type FavouriteContent = Schema["FavouriteContent"]["type"];
export type FavouriteContentIdentifier =
  Schema["FavouriteContent"]["identifier"];
export type FavouriteContentCreateInput =
  Schema["FavouriteContent"]["createType"];
export type FavouriteContentDeleteInput =
  Schema["FavouriteContent"]["deleteType"];

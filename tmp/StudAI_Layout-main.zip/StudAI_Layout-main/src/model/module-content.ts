import { type Schema } from "../../amplify/data/resource";

export type ModuleContent = Schema["ModuleContent"]["type"];
export type ModuleContentIdentifier = Schema["ModuleContent"]["identifier"];
export type ModuleContentCreateInput = Schema["ModuleContent"]["createType"];
export type ModuleContentUpdateInput = Schema["ModuleContent"]["updateType"];
export type ModuleContentDeleteInput = Schema["ModuleContent"]["deleteType"];

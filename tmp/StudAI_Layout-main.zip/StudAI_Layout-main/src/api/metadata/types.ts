export interface ExtractedMetadata {
  title: string;
  description: string;
  image?: string;
  favicon?: string;
  url: string;
  durationInSeconds: number;
  author?: string;
  publishedAt?: string;
  language?: string;
}
